﻿using System;

namespace MVCUserRoles.Models
{
    public class TeachersDetails
    {

        public String TeacherName { get; set; }
        
    }
}